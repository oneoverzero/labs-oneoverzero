---
id: 849
title: 'Convidado Especial &#8211; Sérgio Bernardino'
date: 2016-04-07T11:41:44+00:00
author: Nuno Nunes
layout: page
guid: http://labs.oneoverzero.org/?page_id=849
twitterCardType:
  - summary_large_image
cardImageWidth:
  - "320"
cardImageHeight:
  - "320"
---
Nesta nossa segunda série temos um envolvimento maior do nosso convidado especial.

Tal como o [**Luís Correia**](http://labs.oneoverzero.org/equipa/luis-correia/ "Luís Correia"), também ele pretende construir uma arcade de topo de bancada para joga novamente os seus jogos favoritos. Já no passado ele tinha manifestado o seu interesse numa solução destas e sabíamos que por vezes joga MAME num PC vulgar, pelo que quando decidimos fazer esta série com este tema a decisão de o convidar a fazer a build connosco foi óbvia.

[<img class="aligncenter size-large wp-image-850" src="http://labs.oneoverzero.org/wp-content/uploads/2015/03/sergio_bernardino-1024x1024.png" alt="Sérgio Bernardino" width="640" height="640" srcset="http://labs.oneoverzero.org/wp-content/uploads/2015/03/sergio_bernardino-1024x1024.png 1024w, http://labs.oneoverzero.org/wp-content/uploads/2015/03/sergio_bernardino-150x150.png 150w, http://labs.oneoverzero.org/wp-content/uploads/2015/03/sergio_bernardino-300x300.png 300w, http://labs.oneoverzero.org/wp-content/uploads/2015/03/sergio_bernardino-280x280.png 280w" sizes="(max-width: 640px) 100vw, 640px" />](http://labs.oneoverzero.org/wp-content/uploads/2015/03/sergio_bernardino.png)

&nbsp;

O seu nome é **Sérgio Bernardino** e podem &#8220;encontrá-lo&#8221; no seu site em <a href="http://sergiobernardino.net/" target="_blank">http://sergiobernardino.net/</a> ou a twittar em <a href="http://twitter.com/smpb" target="_blank">http://twitter.com/smpb</a>.

O **Sérgio** identifica-se como sendo&#8230;

> Geek eclético por natureza, curioso por feitio, fotógrafo por paixão, e engenheiro de software de profissão.
> 
> O meu percurso não é muito diferente de todos aqueles que, como aqui nos OOZ Labs, têm uma paixão pela tecnologia. Exposto ao meio desde sempre, os meus interesses são variados mas o foco sempre foi o software.
> 
> O trabalho manual, e a arte do &#8220;making&#8221;, não é o meu forte mas nunca é demasiado tarde para aprender. Vivemos na era do digital, mas admito um gosto pelo analógico. As razões vão desde a simples nostalgia ao fascínio por processos mecânicos como exemplos clássicos do engenho humano.
> 
> E colaborar com os OOZ Labs é celebrar tudo isso.