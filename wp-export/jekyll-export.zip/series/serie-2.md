---
id: 914
title: Série 2
date: 2016-04-07T11:41:07+00:00
author: Nuno Nunes
layout: page
guid: http://labs.oneoverzero.org/?page_id=914
twitterCardType:
  - summary_large_image
cardImageWidth:
  - "320"
cardImageHeight:
  - "320"
---
Bem vindos à segunda série do OOZ Labs, como construir uma arcade de topo de mesa.

<p style="text-align: center;">
</p>

Esta série iniciou-se em 7 de Abril de 2016.  Podem ver todos os vídeos da série na playlist acima e podem consultar cada um dos artigos referentes a todos esses vídeos nos links abaixo.

Lista de episódios:

  * <a href="http://labs.oneoverzero.org/s02e00/" target="_blank">Episódio 0 &#8211; Prólogo</a>
  * <a href="http://labs.oneoverzero.org/s02e01/" target="_blank">Episódio 1 &#8211; Planos e protótipos</a>
  * [Episódio 2 &#8211; Painéis do Armário do Luís](http://labs.oneoverzero.org/s02e02/)
  * [Episódio 3 &#8211; Decisões e Detalhes do Armário da Arcade do Sérgio](http://labs.oneoverzero.org/s02e03/)
  * [Episódio 4 &#8211; Ripas de Suporte (e Quadrados ao Comprido)](http://labs.oneoverzero.org/s02e04/)
  * <a href="http://labs.oneoverzero.org/s02e05/" target="_blank">Episódio 5 &#8211; Considerações sobre Software e Som</a>
  * [Episódio 6 &#8211; Montagem](http://labs.oneoverzero.org/s02e06/)
  * [Episódio 7 &#8211; Área de Jogo](http://labs.oneoverzero.org/s02e07/)
  * [Episódio 8 &#8211; Monitor, Marquee e Porta](http://labs.oneoverzero.org/s02e08/)
  * [Episódio 9 &#8211; Interiores](http://labs.oneoverzero.org/s02e09/)
  * [Episódio 10 &#8211; Electricidade e Electrónica](http://labs.oneoverzero.org/s02e10/)
  * [Episódio 11 &#8211; Finalmente a Jogar!](http://labs.oneoverzero.org/s02e11/)
  * [Episódio 12 &#8211; Epílogo](http://labs.oneoverzero.org/s02e12/)

O convidado especial desta série é o [Sérgio Bernardino](http://labs.oneoverzero.org/series/serie-2/s02-convidado-especial/).

Boa sorte com as vossas construções e bons jogos!