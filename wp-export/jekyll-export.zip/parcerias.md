---
id: 449
title: Parcerias
date: 2015-01-26T14:19:08+00:00
author: OOZ Labs
layout: page
guid: http://labs.oneoverzero.org/?page_id=449
twitterCardType:
  - summary
cardImageWidth:
  - "320"
cardImageHeight:
  - "320"
---
Estabelecemos parcerias, particularmente com a <a title="Teelook" href="http://teelook.pt" target="_blank">Teelook</a>, onde podem comprar t-shirts com o nosso logótipo.

Para poderes encomendar a tua, basta que sigas este <a title="T-shirt OOZ Labs" href="http://teelook.pt/product.php?id_product=502" target="_blank">link</a>.
  
[<img class="aligncenter size-full wp-image-458" src="http://labs.oneoverzero.org/wp-content/uploads/2015/01/502-1059-thickbox.jpg" alt="502-1059-thickbox" width="600" height="600" srcset="http://labs.oneoverzero.org/wp-content/uploads/2015/01/502-1059-thickbox.jpg 600w, http://labs.oneoverzero.org/wp-content/uploads/2015/01/502-1059-thickbox-150x150.jpg 150w, http://labs.oneoverzero.org/wp-content/uploads/2015/01/502-1059-thickbox-300x300.jpg 300w" sizes="(max-width: 600px) 100vw, 600px" />](http://labs.oneoverzero.org/wp-content/uploads/2015/01/502-1059-thickbox.jpg)

Podes encontrar a <a title="Teelook" href="http://teelook.pt" target="_blank">Teelook</a> na página [oficial no Facebook](http://www.facebook.com/teelook) .