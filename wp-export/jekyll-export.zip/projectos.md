---
id: 958
title: Projectos
date: 2015-11-06T14:27:07+00:00
author: OOZ Labs
layout: page
guid: http://labs.oneoverzero.org/?page_id=958
twitterCardType:
  - summary_large_image
cardImageWidth:
  - "320"
cardImageHeight:
  - "320"
---
Esta página contém um apanhado dos projectos que já realizámos no OOZLabs, incluindo também as biografias dos nossos convidados especiais.

&nbsp;

Lisbon Maker Faire 2016

  * [Apresentação do projecto SparroWatch](http://labs.oneoverzero.org/projectomakerfaire2016)

&nbsp;

Lisbon Maker Faire 2015

  * [Projecto One Over Zero 2 Mars](http://labs.oneoverzero.org/ooz2mars-projecto-makerfaire-2015/)
  * [Apresentação do projecto OOZ2Mars](http://labs.oneoverzero.org/projectomakerfaire2015/)
  * [O hardware do Rover](http://labs.oneoverzero.org/ooz2mars-rover-hardware/)

&nbsp;

Lisbon Mini Maker Faire 2014

  * [Projecto](http://labs.oneoverzero.org/lxminimakerfaire/) <a href="http://makerfairelisbon.com/pt/2014/08/12/pointasatelliteinator.html" target="_blank">Point-A-Sateliteinator</a>