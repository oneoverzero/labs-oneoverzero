---
id: 393
title: Séries
date: 2015-01-21T23:56:35+00:00
author: OOZ Labs
layout: page
guid: http://labs.oneoverzero.org/?page_id=393
twitterCardType:
  - summary
cardImageWidth:
  - "320"
cardImageHeight:
  - "320"
---
Somos um colectivo de curiosos que se juntam para construir coisas de interesse comum.

Entre outras coisas, já fizemos longboard skates, quadcopters de esponja rija, reparação de cadeiras de sala, estores de vários tipos, árvores de Natal estilizadas, aviões tele-comandados e muito mais coisas que já nem nos lembramos.

Decidimos criar séries em formato vídeo sobre construções de equipamento ou gadgets para nossa diversão.

&nbsp;

A primeira é sobre a construção de um quadcopter, que podes seguir através deste link: [Série 1 &#8211; Quadcopter](http://labs.oneoverzero.org/serie-1/ "Série 1 - Quadcopter").

A segunda, que está a decorrer agora, é sobre a construção de máquinas de jogos (tipo arcada) de topo de mesa e podes encontrar os posts todos em [Série 2 &#8211; Arcada](http://labs.oneoverzero.org/series/serie-2/).

&nbsp;

[Voltar ao início](http://labs.oneoverzero.org "Inicio")