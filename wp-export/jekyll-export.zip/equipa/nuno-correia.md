---
id: 596
title: Nuno Correia
date: 2015-02-10T12:35:01+00:00
author: Nuno Correia
layout: page
guid: http://labs.oneoverzero.org/?page_id=596
twitterCardType:
  - summary_large_image
cardImageWidth:
  - "320"
cardImageHeight:
  - "320"
---
<figure id="attachment_600" style="width: 640px" class="wp-caption aligncenter"><img class="wp-image-600 size-large" src="http://labs.oneoverzero.org/wp-content/uploads/2015/02/nc-1024x1024.png" alt="Nuno Correia" width="640" height="640" srcset="http://labs.oneoverzero.org/wp-content/uploads/2015/02/nc.png 1024w, http://labs.oneoverzero.org/wp-content/uploads/2015/02/nc-150x150.png 150w, http://labs.oneoverzero.org/wp-content/uploads/2015/02/nc-300x300.png 300w, http://labs.oneoverzero.org/wp-content/uploads/2015/02/nc-280x280.png 280w" sizes="(max-width: 640px) 100vw, 640px" /><figcaption class="wp-caption-text">Nuno Correia</figcaption></figure> 

&nbsp;