---
id: 377
title: Luís Correia
date: 2015-02-10T12:34:19+00:00
author: Luis Correia
layout: page
guid: http://labs.oneoverzero.org/?page_id=377
twitterCardType:
  - summary
cardImageWidth:
  - "320"
cardImageHeight:
  - "320"
image: /wp-content/uploads/2015/01/lc_c.png
---
[<img class="aligncenter size-large wp-image-574" src="http://labs.oneoverzero.org/wp-content/uploads/2015/01/lc_c-1024x1024.png" alt="lc_c" width="640" height="640" srcset="http://labs.oneoverzero.org/wp-content/uploads/2015/01/lc_c.png 1024w, http://labs.oneoverzero.org/wp-content/uploads/2015/01/lc_c-150x150.png 150w, http://labs.oneoverzero.org/wp-content/uploads/2015/01/lc_c-300x300.png 300w, http://labs.oneoverzero.org/wp-content/uploads/2015/01/lc_c-280x280.png 280w" sizes="(max-width: 640px) 100vw, 640px" />](http://labs.oneoverzero.org/wp-content/uploads/2015/01/lc_c.png)Tem uma relação de 40 anos com a electrónica e diz que entende alguma coisa dos computadores. Desde pequeno que desmonta tudo o que deixou de funcionar ou que pretende saber como é que funciona por dentro. Por esta razão, o único brinquedo que conseguiu realmente escapar à sua infância foi um bloco de 2&#215;4 LEGO(TM).

Vive rodeado de computadores desde 1983, o ano em que lhe ofereceram um Sinclair ZX Spectrum vindo directamente de Inglaterra. Desde então, tem pesadelos com a afinação da cabeça do leitor de cassetes&#8230;

De dia navega entre a gestão e manutenção de sistemas informáticos, de noite dedica-se à sua faceta MAKER.

Tenta reparar tudo o que lhe chega às mãos embora a taxa de sucesso não seja muito elevada. Claro que isto dá-lhe a desculpa para desmontar tudo e continuar com o seu passatempo favorito.

Usa computadores que correm uma coisa estranha chamada Linux e insiste que é uma das melhores coisas à face da terra.

A sua bio no Twitter diz &#8220;Luís Correia: Linux e-vangelist & developer, HACKER MAKER electronics wizz, biker and all around explorer. technologist since 1982&#8221;.

Tem uma wishlist na Amazon que preparou no natal de 2014, mas que não deu os resultados esperados (<a class="twitter-timeline-link" dir="ltr" title="http://b.loide.net/2014_LC_Natal" href="http://t.co/7IFOQ5pBvV" target="_blank" rel="nofollow" data-expanded-url="http://b.loide.net/2014_LC_Natal"><span class="invisible">http://</span><span class="js-display-url">b.loide.net/2014_LC_Natal</span></a>)

&nbsp;

&nbsp;