---
id: 6
title: Contacto
date: 2014-07-29T18:10:48+00:00
author: OOZ Labs
layout: page
guid: http://labs.oneoverzero.org/?page_id=6
twitterCardType:
  - summary
cardImageWidth:
  - "320"
cardImageHeight:
  - "320"
---
Portanto, queres dizer-nos algo, não é?

Sendo assim estamos presentes nestas redes sociais:

  * <a title="OOZ Labs" href="http://twitter.com/oozlabs" target="_blank">Twitter</a>
  * <a title="OOZ Labs" href="http://facebook.com/oozlabs" target="_blank">Facebook</a>
  * <a title="OOZ Labs" href="http://instagram.com/oozlabs" target="_blank">Instagram</a>
  * <a title="OOZ Labs" href="https://plus.google.com/108701695142339153954" target="_blank">Google+</a>
  * <a title="OOZ Labs" href="https://www.youtube.com/channel/UCyupGmfELyDSQZK7rDBpaJw" target="_blank">Canal YouTube</a>

Se o que pretendes é mais informação sobre nós, tens aqui um [press kit](http://cdn.labs.oneoverzero.org/PressKit201502/Press%20Kit%20OOZ%20Labs.zip) recheado de informação.

Se não gostares de falar connosco através das redes sociais, preenche este pequeno form e entraremos em contacto contigo assim que nos for possível!

<div role="form" class="wpcf7" id="wpcf7-f8-o1" lang="en-US" dir="ltr">
  <div class="screen-reader-response">
  </div>
</div>

&nbsp;